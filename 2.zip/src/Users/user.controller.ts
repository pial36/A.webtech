// user.controller.ts
import { Controller, Get, Post, Body, Put, Param, Query, UsePipes, ValidationPipe } from '@nestjs/common';
import { UserService } from './user.service';
import { UserDTO } from './user.dto';

@Controller('users')
export class UserController {
    constructor(private readonly userService: UserService) {}

    @Post('create')
    @UsePipes(new ValidationPipe())
    createUser(@Body() userDto: UserDTO): Promise<string> {
        return this.userService.createUser(userDto);
    }

    @Put('status/:id')
    @UsePipes(new ValidationPipe())
    changeUserStatus(@Param('id') id: number, @Body('status') status: string): Promise<string> {
        return this.userService.changeUserStatus(id, status);
    }

    @Get('inactive')
    getUsersByInactiveStatus(): Promise<string> {
        return this.userService.getUsersByInactiveStatus();
    }

    @Get('older-than-40')
    getUsersOlderThan40(@Query('age') age: number): Promise<string> {
        return this.userService.getUsersOlderThan40(age);
    }
}
