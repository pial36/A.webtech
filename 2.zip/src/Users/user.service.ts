// user.service.ts
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository,MoreThan } from 'typeorm';
import { UserEntity } from './user.entity';
import { UserDTO } from './user.dto';

@Injectable()
export class UserService {
    constructor(
        @InjectRepository(UserEntity)
        private readonly userRepository: Repository<UserEntity>,
    ) {}

    async createUser(userDto: UserDTO): Promise<string> {
        const user = this.userRepository.create(userDto);
        await this.userRepository.save(user);
        return 'User created successfully';
    }

    async changeUserStatus(id: number, status: string): Promise<string> {
        await this.userRepository.update(id, { status });
        return `Status of user with id ${id} changed to ${status}`;
    }

    async getUsersByInactiveStatus(): Promise<string> {
        const users = await this.userRepository.find({ where: { status: 'inactive' } });
        return JSON.stringify(users);
    }

    async getUsersOlderThan40(age: number): Promise<string> {
        const users = await this.userRepository.find({ where: { age: MoreThan(40) } });
        return JSON.stringify(users);
    }
}
