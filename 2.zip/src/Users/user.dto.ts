// user.dto.ts
import { IsString, IsInt, IsNotEmpty, IsIn } from 'class-validator';

export class UserDTO {
    @IsInt({ message: 'Id must be an integer' })
    id: number;

    @IsNotEmpty({ message: 'fullName is required' })
    @IsString({ message: 'fullName must be a string' })
    fullName: string;

    @IsNotEmpty({ message: 'Age is required' })
    @IsInt({ message: 'Age must be an integer' })
    age: number;

    @IsString({ message: 'Status must be a string' })
    @IsIn(['active', 'inactive'], { message: 'Status must be either active or inactive' })
    status: string;
}
