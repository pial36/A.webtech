import { Injectable } from "@nestjs/common";

@Injectable()
export class AdminService{
    getIndex(): string
    {
        return "Hello world";
    
    }
    getUsersById(id: number):object{
        console.log(id);
        return {message: "your id is " + id};


    }
    getUsersByNameAndId(name:string, id:string): object{
        return {message:"Your Name Is "+name
    + "and your Id is"};
    }
    addAmin(myobj:object):object{
        return myobj;
    }
}