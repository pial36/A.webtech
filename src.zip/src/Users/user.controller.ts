
import { Body, Controller, Get, Param, Post, Put, Patch, Delete, Query, UsePipes, ValidationPipe } from "@nestjs/common";
import { UserService } from "./user.service";
import { UserDTO } from "./user.dto";

@Controller('/users')
export class UserController {
    constructor(private readonly userService: UserService) {}

    @Get()
    getAllUsers(): object {
        return this.userService.getAllUsers();
    }

    @Get(':id')
    getUserById(@Param('id') id: string): object {
        return this.userService.getUserById(id);
    }

    @Get('/search')
    getUsersByNameAndId(@Query('name') name: string, @Query('id') id: string): object {
        return this.userService.getUsersByNameAndId(name, id);
    }

    @Post('/add')
    @UsePipes(new ValidationPipe())
    async createUser(@Body() user: UserDTO): Promise<UserDTO> {
        return this.userService.createUser(user);
    }

    @Put(':id')
    @UsePipes(new ValidationPipe())
    async updateUser(@Param('id') id: string, @Body() user: UserDTO): Promise<UserDTO> {
        return this.userService.updateUser(id, user);
    }

    @Patch(':id')
    @UsePipes(new ValidationPipe())
    async partialUpdateUser(@Param('id') id: string, @Body() partialUser: Partial<UserDTO>): Promise<UserDTO> {
        return this.userService.partialUpdateUser(id, partialUser);
    }

    @Delete(':id')
    deleteUser(@Param('id') id: string): object {
        return this.userService.deleteUser(id);
    }
}
