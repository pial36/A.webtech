
export class UserDTO {
    id: string;
    name: string;
    email: string;

}
