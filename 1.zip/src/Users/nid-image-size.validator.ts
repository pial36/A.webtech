
import { ValidationOptions, registerDecorator, ValidationArguments } from 'class-validator';

export function IsNidImageSizeValid(validationOptions?: ValidationOptions) {
    return function (object: any, propertyName: string) {
        registerDecorator({
            name: 'isNidImageSizeValid',
            target: object.constructor,
            propertyName: propertyName,
            options: validationOptions,
            validator: {
                async validate(value: any, args: ValidationArguments) {
                    if (!value) {
                        return true; 
                    }

                    const maxFileSizeInBytes = 2 * 1024 * 1024; // 2 MB
                    const fileBuffer = Buffer.from(value, 'base64');
                    return fileBuffer.length <= maxFileSizeInBytes;
                },
                defaultMessage(args: ValidationArguments) {
                    return `${args.property} must be a NID image with a size no more than 2 MB`;
                },
            },
        });
    };
}
