
import { Injectable } from "@nestjs/common";
import { UserDTO } from "./user.dto";

@Injectable()
export class UserService {

    private users: UserDTO[] = [];

    getAllUsers(): object {
        return { users: this.users };
    }

    getUserById(id: string): object {
        const user = this.users.find(u => u.id === id);
        return user ? { user } : { message: 'User not found' };
    }

    getUsersByNameAndId(name: string, id: string): object {

        return { message: `Filtering users by name: ${name} and id: ${id}` };
    }

    async createUser(user: UserDTO): Promise<UserDTO> {
        this.users.push(user);
        return user;
    }

    async updateUser(id: string, user: UserDTO): Promise<UserDTO> {

        return user;
    }

    async partialUpdateUser(id: string, partialUser: Partial<UserDTO>): Promise<UserDTO> {

        return partialUser as UserDTO;
    }

    deleteUser(id: string): object {

        return { message: `User with id ${id} deleted` };
    }
}
