import { IsString, IsEmail, IsNotEmpty, Matches, IsNumberString, IsOptional } from 'class-validator';
import { IsEmailWithXyzDomain } from './email-domain.validator';
import { IsNidImageSizeValid } from './nid-image-size.validator';


export class UserDTO {
    id: string; 

    @IsString({ message: 'Name should only contain alphabets' })
    name: string;

    @IsEmailWithXyzDomain({ message: 'Invalid email format or not in .xyz domain' })
    @IsNotEmpty({ message: 'Email address is required' })
    email: string;

    @IsNotEmpty({ message: 'Password is required' })
    @Matches(/^(?=.*[0-9])/, { message: 'Password must contain at least one numeric character' })
    password: string;

    @IsNumberString({}, { message: 'Invalid NID format' })
    @IsNotEmpty({ message: 'NID number is required' })
    nid: string;

    @IsNidImageSizeValid({ message: 'Invalid NID image size' })
    @IsNotEmpty({ message: 'NID image is required' })
    nidImage: string; 

    @IsOptional()
    @Matches(/^018-\d{7}$/, { message: 'Invalid phone number format' })
    phoneNumber: string;
}
