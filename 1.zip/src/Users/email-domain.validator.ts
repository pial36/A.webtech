
import { ValidationOptions, registerDecorator, ValidationArguments } from 'class-validator';

export function IsEmailWithXyzDomain(validationOptions?: ValidationOptions) {
    return function (object: any, propertyName: string) {
        registerDecorator({
            name: 'isEmailWithXyzDomain',
            target: object.constructor,
            propertyName: propertyName,
            options: validationOptions,
            validator: {
                validate(value: any, args: ValidationArguments) {
                    const regex = /^[a-zA-Z0-9._-]+@([a-zA-Z0-9-]+\.)+xyz$/;
                    return typeof value === 'string' && regex.test(value);
                },
                defaultMessage(args: ValidationArguments) {
                    return `${args.property} must be a valid email address with .xyz domain`;
                },
            },
        });
    };
}
